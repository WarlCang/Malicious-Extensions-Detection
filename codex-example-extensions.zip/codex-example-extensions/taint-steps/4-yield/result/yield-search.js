// yield
// extension: ecmeogcbcoalojmkfkmancobmiahaigg.3_7_5_0
// file: ./product_analysis/product_analysis.js


// simplest
const t = yield O.Z.getId(e);
window.open(`https://itemscout.io/keyword?id=${t}`, "_blank")


// snippet
const m = e => P(this, void 0, void 0, (function*() {
    const t = yield O.Z.getId(e);
    window.open(`https://itemscout.io/keyword?id=${t}`, "_blank")
})),