(function() {
	var isExtension = (window.chrome && chrome.runtime);
	var useJSONP = !isExtension;

	var form = document.getElementById("search-form");
	var input = document.getElementById("search-input");
	var hiddenInput = false;

	var loadJSONP = function(id, url) {
		var fullId = 'script-jsonp-' + id;
		var oldScript = document.getElementById(fullId);
		if (oldScript)
			oldScript.parentNode.removeChild(oldScript);
		var script = document.createElement('script');
		script.src = url;
		script.setAttribute('id', fullId);
		document.head.appendChild(script);
	};
	var loadJSON = function(id, url) {
	    var xhr = new XMLHttpRequest();
	    xhr.open('GET', url, true);
	    xhr.onload = function() {
	        try {
	            var resp = JSON.parse(xhr.responseText);
	            window[id](resp);
	        } catch (e) {};
	    };
	    xhr.send(null);
	};

	var loadData = useJSONP ? loadJSONP : loadJSON;

	var filterSuggest = function(input, data) {
		if (data && data[0] && data[1] && data[0].trim && data[0].trim() == input.trim()) {
			var result = data[1];
			if ( input.trim() && (!result[0] || (result[0].trim() != input.trim())) )
				result.unshift(input);
			//console.log(input, result);
			return result;
		} else {
			return false;
		}
	};


	var lastSid = false;
	var awesomplete = {};

	var originalText = false;
	input.addEventListener('input', function(e){
		originalText = input.value;
	});

	var insertInputText = function(text) {
		if (input.value == text) return;
		var disableInputEvent = function(e) {
			e.stopImmediatePropagation();
			e.stopPropagation();
			e.preventDefault();
			return false;
		};
		window.addEventListener('input', disableInputEvent, true);
		input.focus();
		document.execCommand('selectAll', false);
		document.execCommand('insertText', false, text);
		if (hiddenInput) hiddenInput.value = text;
		setTimeout(function(){
			window.removeEventListener('input', disableInputEvent, true);
		}, 0);
	};
	var extractText = function(e) {
		var text = false;
		if (e && e.text) {
			text = e.text;
			if (text.indexOf('<font class="url-color"') >= 0) {
				text = decodeURIComponent(
					e.selectedNode.getElementsByTagName('font')[0].getAttribute('data-url').replace(/<\/?[^>]+>/gi, '')
				);
			}
		}
		return text;
	};
	input.addEventListener('awesomplete-highlight', function(e){
		var text = extractText(e);
		insertInputText(text);
	});
	input.addEventListener('awesomplete-close', function(e) {
		if (e && e.reason == 'esc') {
			awesomplete.goto(-1, true);
			awesomplete.open();
			if (originalText) 
				insertInputText(originalText);
		}
	});

	input.focus();
	document.body.addEventListener('click', function(){
		input.focus();
	});
	setTimeout(input.focus.bind(input), 100);


	var openURL = function(url, newTab) {
		if (newTab) {
			if (isExtension) {
				chrome.runtime.sendMessage({openURL: url});
			} else {
				window.open(url);
			}
		} else {
			location.href = url;
		}
	};

	var serializeForm = function() {
		var url = form.action;
		url += (form.action.indexOf('?') >= 0) ? '&' : '?';
		var inputs = form.getElementsByTagName('input');
		var params = [];
		for (var i = 0; i < inputs.length; i++) {
			params.push(encodeURIComponent(inputs[i].name) + '=' + encodeURIComponent(inputs[i].value));
		}
		url += params.join('&');
		return url;
	};

	var submitForm = function(newTab) {
		var url = serializeForm();
		var rawLocation = false;
		openURL(url, newTab);
	};

	form.addEventListener('submit', function(e) {
		e.preventDefault();
		submitForm();
	});

	input.addEventListener('awesomplete-selectcomplete', function(e){
		var text = extractText(e);
		insertInputText(text);
		submitForm();
	});

	input.addEventListener('keydown', function(e){
		if (e && e.code) {
			if (e.code == 'Enter') {
				e.preventDefault();
				if (e.altKey || e.ctrlKey)
					return;
				submitForm(e.shiftKey);
			}
		}
	});

	function htmlEntities(str) {
	    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
	}

	function cutString(str, len) {
		return (str.slice(0, len) + (str.length > len ? '...' : ''));
	}
})();