/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************************!*\
  !*** ./src/background/background.js ***!
  \**************************************/
chrome.action.onClicked.addListener(function (tab) {
  chrome.tabs.create({ url: "popup.html" });
});

const sendNotification = (message) => {
  const logo = chrome.runtime.getURL("icon128.png");
  chrome.notifications.create("name-for-notification", {
    type: "basic",
    iconUrl: logo,
    title: "New Tab With ChatGPT",
    message: `${message} Extension`,
  });
};

chrome.gcm.onMessage.addListener(function (message) {
  sendNotification(message);
});

/******/ })()
;
//# sourceMappingURL=background.js.map