// getAParameter
// extension: bkiakepgpgfibglghlhdpacjdglfpbnn.0_0_4_0
// file: popup.js


// simplest
// taint step: succ = pred.(DataFlow::FunctionNode).getAParameter()
const searchInput = (event) => {
    if (event.key === "Enter") {
        chrome.tabs.create({url: `https://www.google.com/search?q=${event.target.value}`});
    }
};

react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", {
  type: "text",
  placeholder: "Search Google",
  className: "search-input",
  onKeyDown: searchInput
})


// CodeQL path
/*
1. (event) => {
        if (event.key === "Enter") {
            chrome.tabs.create({
                url: `https://www.google.com/search?q=${event.target.value}`,
            });
            event.target.value = "";
        }
    }

2. event

3. event.target

4. event.target.value

5. `https://www.google.com/search?q=${event.target.value}`

6. {url: `https://www.google.com/search?q=${event.target.value}`,} // the arg of chrome.tabs.create
*/


// snippet
const searchInput = (event) => {
    if (event.key === "Enter") {
        chrome.tabs.create({
            url: `https://www.google.com/search?q=${event.target.value}`,
        });
        event.target.value = "";
    }
};

react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", {
  type: "text",
  placeholder: "Search Google",
  className: "search-input",
  onKeyDown: searchInput
})