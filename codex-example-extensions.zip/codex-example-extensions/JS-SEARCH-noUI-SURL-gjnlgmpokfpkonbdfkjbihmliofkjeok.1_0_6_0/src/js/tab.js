var alphasearch = function() {
    var url = 'https://ddksearch.com/search?q=' + document.getElementById('search-input').value;
    window.top.location = url;
};

document.getElementById("search-input").onkeypress = function(e)
{
    if (e.which === 13) {
        alphasearch();
    }
};

function startDictation()
{
    if (window.hasOwnProperty('webkitSpeechRecognition'))
    {
        var recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = "en-US";
        recognition.start();
        recognition.onresult = function (e)
        {
            document.getElementById('search-input').value = e.results[0][0].transcript;
            recognition.stop();
            alphasearch(e.results[0][0].transcript);
        };
        recognition.onerror = function(e) {
            recognition.stop();
        }
    }
}