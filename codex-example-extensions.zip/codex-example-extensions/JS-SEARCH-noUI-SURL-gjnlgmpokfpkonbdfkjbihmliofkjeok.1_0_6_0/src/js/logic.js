$(function() {
  function handle_most_vis(mostVisitedURLs) {
    var arrSuggestedSites = [];
    var popupDiv = document.getElementById('tiles');
    let addArr = JSON.parse(window.localStorage.getItem('addItem'))
    let remoArr = JSON.parse(window.localStorage.getItem('removeItem'))
    addArr = addArr.reverse();
    mostVisitedURLs = addArr.concat(mostVisitedURLs);
    mostVisitedURLs = mostVisitedURLs.filter((elem) => !remoArr.find(({
      title
    }) => elem.title === title));
    let length = mostVisitedURLs.length > 8 ? 8 : mostVisitedURLs.length;
    if (mostVisitedURLs) {
      for (var i = 0; i < length; i++) {
        var a = popupDiv.appendChild(document.createElement('div'));
        a.className = "card";
        var anchor = a.appendChild(document.createElement('a'));
        anchor.className = "parent-container ";
        var container = anchor.appendChild(document.createElement('div'));
        container.className = "node-name"
        var internalDiv = container.appendChild(document.createElement('span'));
        internalDiv.className = "linking"
        var textNode = mostVisitedURLs[i].title;
        let srcVal = ""
        if (window.localStorage.getItem("arrSuggestedSites")) {
          window.localStorage.setItem("tmpFirstTime", "No");
          var suggestedSites = JSON.parse(window.localStorage.getItem("arrSuggestedSites"));
          var objIndex = suggestedSites.findIndex((obj => obj.oldname == mostVisitedURLs[i].title));
          anchor.href = (suggestedSites[objIndex]) ? suggestedSites[objIndex].url : mostVisitedURLs[i].url;
          srcVal = (suggestedSites[objIndex]) ? suggestedSites[objIndex].url : mostVisitedURLs[i].url;
          textNode = (suggestedSites[objIndex]) ? suggestedSites[objIndex].name : mostVisitedURLs[i].title;
        } else {
          srcVal = mostVisitedURLs[i].url;
          anchor.href = mostVisitedURLs[i].url;
        }
        let content = `<div class="child-img">
                  <img width="20" class="" src="https://www.google.com/s2/favicons?sz=128&domain=${srcVal}" onerror = "'main_icon.png';" />
              </div>`;
        internalDiv.insertAdjacentHTML('afterbegin', content)
        anchor.title = textNode;
        anchor.appendChild(document.createTextNode(textNode));
        anchor.addEventListener('click', onAnchorClick);
        var tmpIsFirstTime = window.localStorage.getItem("tmpFirstTime");
        if (tmpIsFirstTime == "Yes") {
          arrSuggestedSites.push({
            "name": mostVisitedURLs[i].title,
            "url": mostVisitedURLs[i].url,
            "oldname": mostVisitedURLs[i].title
          });
          window.localStorage.setItem("arrSuggestedSites", JSON.stringify(arrSuggestedSites));
        }
      }

      let temp2 = ''
 

      if (mostVisitedURLs.length < 8) {
        $("#tiles").append(temp2)
      }

      $(".node-name a").css("font-size", "12px");
      $(".node-name a").css("font-weight", "500px");
    }
  }

  function onAnchorClick(event, customUrl = null) {
    // NProgress.start();
    // NProgress.set(0.4);
    // NProgress.configure({
    //   easing: 'ease',
    //   speed: 500,
    //   trickleSpeed: 200,
    //   showSpinner: false,
    //   parent: '#form-search-Text'
    // });
    // setTimeout(function() {
    //   // chrome.tabs.create({ url: event });
    //   NProgress.inc();
    //   if (customUrl == null) {
    //     window.location.href = event.srcElement.href;
    //   } else {
    //     window.location.href = customUrl;
    //   }
    //   NProgress.done();
    // }, 2000);
    // NProgress.done();
    // return false;
  }

  function onOptionsClick() {
    $('#frmModal').css("visibility", "");
    $("#txtShortCutName").val(this.text);
    $("#lblOldName").text(this.text)
    $("#txtShortCutName").text(this.text);
    $("#txtShortCutUrl").val(this.href);
    $('#frmModal').show();
  }
  $(document).ready(function() {
    chrome.topSites.get(handle_most_vis);
  });
});
