import {
  o as d,
  c as g,
  a as m,
  T as f
} from "./vendor.db840a70.js";
const b = function () {
  const e = document.createElement("link").relList;
  if (e && e.supports && e.supports("modulepreload")) return;
  for (const n of document.querySelectorAll('link[rel="modulepreload"]')) t(n);
  new MutationObserver(n => {
    for (const i of n)
      if (i.type === "childList")
        for (const o of i.addedNodes) o.tagName === "LINK" && o.rel === "modulepreload" && t(o)
  }).observe(document, {
    childList: !0,
    subtree: !0
  });

  function r(n) {
    const i = {};
    return n.integrity && (i.integrity = n.integrity), n.referrerpolicy && (i.referrerPolicy = n.referrerpolicy), n.crossorigin === "use-credentials" ? i.credentials = "include" : n.crossorigin === "anonymous" ? i.credentials = "omit" : i.credentials = "same-origin", i
  }

  function t(n) {
    if (n.ep) return;
    n.ep = !0;
    const i = r(n);
    fetch(n.href, i)
  }
};
b();
const s = chrome || browser,
  p = a => new Promise(e => setTimeout(e, a));
var E = {
  wait: p,
  closeTab: w,
  openTab: y,
  openPopup: k,
  getURL: v,
  sendMsg: S,
  onMsg: L,
  isRTL: T,
  blobToBase64: M,
  detectLanguage: C,
  setPopupBadge: B,
  isIframe: _
};

function w() {
  s.tabs.getCurrent(function (a) {
    s.tabs.remove(a.id, function () {})
  })
}

function y(a) {
  s.tabs.create({
    url: a
  })
}

function k(a) {
  s.windows.create({
    url: a,
    type: "popup",
    height: 800,
    width: 800
  })
}

function v(a) {
  return s.runtime.getURL(a)
}

function S(a, e) {
  s.runtime.sendMessage(a, e)
}

function L(a) {
  s.runtime.onMessage.addListener(a)
}

function T(a) {
  return ["ar", "fa", "iw", "yi", "ur", "pa"].indexOf(a) > -1
}

function M(a) {
  return new Promise((e, r) => {
    const t = new FileReader;
    t.onloadend = () => e(t.result), t.readAsDataURL(a)
  })
}

function C() {
  return navigator ? navigator.languages ? c(navigator.languages[0]) : c(navigator.language) : null
}

function c(a) {
  return a.split("-")[0]
}

function B(a) {
  s.action.setBadgeText({
    text: a
  }), s.action.setBadgeBackgroundColor({
    color: [255, 0, 0, 255]
  })
}

function _() {
  return window.self !== window.top
}
var z = (a, e) => {
  const r = a.__vccOpts || a;
  for (const [t, n] of e) r[t] = n;
  return r
};
const j = {},
  x = {
    class: "footer-center p-5"
  },
  A = m('', 1),
  G = [A];

function H(a, e) {
  return d(), g("footer", x, G)
}
var J = z(j, [
  ["render", H]
]);
const u = chrome || browser;
var X = {
  get: U,
  set: P,
  remove: O
};
const K = 8e3;
async function P(a, e) {
  if (!(JSON.stringify(e).length > K)) return await u.storage.sync.set({
    [a]: e
  })
}
async function U(a) {
  const e = await u.storage.sync.get(a) || {};
  return a ? e[a] : e
}
async function O(a) {
  return await u.storage.sync.remove(a)
}
var F = {
  lang: "en",
  settings: {
    src: "auto",
    target: "vi",
    icon: !0,
    dbclick: !0,
    shift: !0,
    tts: !0,
    hotkeysTranslate: !0
  },
  languages: {
    sl: {
      auto: "Detect language",
      af: "Afrikaans",
      sq: "Albanian",
      am: "Amharic",
      ar: "Arabic",
      hy: "Armenian",
      az: "Azerbaijani",
      eu: "Basque",
      be: "Belarusian",
      bn: "Bengali",
      bs: "Bosnian",
      bg: "Bulgarian",
      ca: "Catalan",
      ceb: "Cebuano",
      ny: "Chichewa",
      "zh-CN": "Chinese",
      co: "Corsican",
      hr: "Croatian",
      cs: "Czech",
      da: "Danish",
      nl: "Dutch",
      en: "English",
      eo: "Esperanto",
      et: "Estonian",
      tl: "Filipino",
      fi: "Finnish",
      fr: "French",
      fy: "Frisian",
      gl: "Galician",
      ka: "Georgian",
      de: "German",
      el: "Greek",
      gu: "Gujarati",
      ht: "Haitian Creole",
      ha: "Hausa",
      haw: "Hawaiian",
      iw: "Hebrew",
      hi: "Hindi",
      hmn: "Hmong",
      hu: "Hungarian",
      is: "Icelandic",
      ig: "Igbo",
      id: "Indonesian",
      ga: "Irish",
      it: "Italian",
      ja: "Japanese",
      jw: "Javanese",
      kn: "Kannada",
      kk: "Kazakh",
      km: "Khmer",
      rw: "Kinyarwanda",
      ko: "Korean",
      ku: "Kurdish (Kurmanji)",
      ky: "Kyrgyz",
      lo: "Lao",
      la: "Latin",
      lv: "Latvian",
      lt: "Lithuanian",
      lb: "Luxembourgish",
      mk: "Macedonian",
      mg: "Malagasy",
      ms: "Malay",
      ml: "Malayalam",
      mt: "Maltese",
      mi: "Maori",
      mr: "Marathi",
      mn: "Mongolian",
      my: "Myanmar (Burmese)",
      ne: "Nepali",
      no: "Norwegian",
      or: "Odia (Oriya)",
      ps: "Pashto",
      fa: "Persian",
      pl: "Polish",
      pt: "Portuguese",
      pa: "Punjabi",
      ro: "Romanian",
      ru: "Russian",
      sm: "Samoan",
      gd: "Scots Gaelic",
      sr: "Serbian",
      st: "Sesotho",
      sn: "Shona",
      sd: "Sindhi",
      si: "Sinhala",
      sk: "Slovak",
      sl: "Slovenian",
      so: "Somali",
      es: "Spanish",
      su: "Sundanese",
      sw: "Swahili",
      sv: "Swedish",
      tg: "Tajik",
      ta: "Tamil",
      tt: "Tatar",
      te: "Telugu",
      th: "Thai",
      tr: "Turkish",
      tk: "Turkmen",
      uk: "Ukrainian",
      ur: "Urdu",
      ug: "Uyghur",
      uz: "Uzbek",
      vi: "Vietnamese",
      cy: "Welsh",
      xh: "Xhosa",
      yi: "Yiddish",
      yo: "Yoruba",
      zu: "Zulu"
    },
    tl: {
      af: "Afrikaans",
      sq: "Albanian",
      am: "Amharic",
      ar: "Arabic",
      hy: "Armenian",
      az: "Azerbaijani",
      eu: "Basque",
      be: "Belarusian",
      bn: "Bengali",
      bs: "Bosnian",
      bg: "Bulgarian",
      ca: "Catalan",
      ceb: "Cebuano",
      ny: "Chichewa",
      "zh-CN": "Chinese (Simplified)",
      "zh-TW": "Chinese (Traditional)",
      co: "Corsican",
      hr: "Croatian",
      cs: "Czech",
      da: "Danish",
      nl: "Dutch",
      en: "English",
      eo: "Esperanto",
      et: "Estonian",
      tl: "Filipino",
      fi: "Finnish",
      fr: "French",
      fy: "Frisian",
      gl: "Galician",
      ka: "Georgian",
      de: "German",
      el: "Greek",
      gu: "Gujarati",
      ht: "Haitian Creole",
      ha: "Hausa",
      haw: "Hawaiian",
      iw: "Hebrew",
      hi: "Hindi",
      hmn: "Hmong",
      hu: "Hungarian",
      is: "Icelandic",
      ig: "Igbo",
      id: "Indonesian",
      ga: "Irish",
      it: "Italian",
      ja: "Japanese",
      jw: "Javanese",
      kn: "Kannada",
      kk: "Kazakh",
      km: "Khmer",
      rw: "Kinyarwanda",
      ko: "Korean",
      ku: "Kurdish (Kurmanji)",
      ky: "Kyrgyz",
      lo: "Lao",
      la: "Latin",
      lv: "Latvian",
      lt: "Lithuanian",
      lb: "Luxembourgish",
      mk: "Macedonian",
      mg: "Malagasy",
      ms: "Malay",
      ml: "Malayalam",
      mt: "Maltese",
      mi: "Maori",
      mr: "Marathi",
      mn: "Mongolian",
      my: "Myanmar (Burmese)",
      ne: "Nepali",
      no: "Norwegian",
      or: "Odia (Oriya)",
      ps: "Pashto",
      fa: "Persian",
      pl: "Polish",
      pt: "Portuguese",
      pa: "Punjabi",
      ro: "Romanian",
      ru: "Russian",
      sm: "Samoan",
      gd: "Scots Gaelic",
      sr: "Serbian",
      st: "Sesotho",
      sn: "Shona",
      sd: "Sindhi",
      si: "Sinhala",
      sk: "Slovak",
      sl: "Slovenian",
      so: "Somali",
      es: "Spanish",
      su: "Sundanese",
      sw: "Swahili",
      sv: "Swedish",
      tg: "Tajik",
      ta: "Tamil",
      tt: "Tatar",
      te: "Telugu",
      th: "Thai",
      tr: "Turkish",
      tk: "Turkmen",
      uk: "Ukrainian",
      ur: "Urdu",
      ug: "Uyghur",
      uz: "Uzbek",
      vi: "Vietnamese",
      cy: "Welsh",
      xh: "Xhosa",
      yi: "Yiddish",
      yo: "Yoruba",
      zu: "Zulu"
    },
    al: {}
  }
};
const l = f.google,
  h = 5e3;
var Y = {
  getLanguages: I,
  translate: N,
  tts: R,
  ttsBlob: q
};
async function I(a) {
  try {
    const e = l.getLanguages(a);
    return await (await fetch(e.url, {
      method: e.method,
      headers: e.headers
    })).json()
  } catch {
    return F.languages
  }
}
async function N(a = "en", e, r, t) {
  if (e.length > h) return alert(`Maximum text length exceeded: ${h}`), {};
  const n = l.translate(a, e, r, t),
    o = await (await fetch(n.url, {
      method: n.method,
      headers: n.headers
    })).json();
  return o.text = e, o.target = t, o
}
async function R(a = "en", e, r) {
  const t = l.tts(a, e, "input", r),
    i = await (await fetch(t.url, {
      method: t.method,
      headers: t.headers
    })).blob();
  return URL.createObjectURL(i)
}
async function q(a = "en", e, r) {
  const t = l.tts(a, e, "input", r);
  return await (await fetch(t.url, {
    method: t.method,
    headers: t.headers
  })).blob()
}
export {
  F as D, J as F, Y as G, E as H, X as S, z as _
};