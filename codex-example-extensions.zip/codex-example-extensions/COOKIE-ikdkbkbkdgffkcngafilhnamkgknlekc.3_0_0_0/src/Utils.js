class Config {
  constructor(t) {
    this.config = {}, chrome.storage.local.get(null, function (n) {
      this.config = n, t && t()
    }.bind(this)), chrome.storage.onChanged.addListener(function (t, n) {
      chrome.storage.local.get(null, function (t) {
        this.config = t
      }.bind(this))
    }.bind(this))
  }
  getUserID() {
    if (this.config.uid) return this.config.uid; {
      let t = new Uint32Array(4),
        n = -1;
      crypto.getRandomValues(t);
      let x = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (x) {
        n++;
        let i = t[n >> 3] >> n % 8 * 4 & 15;
        return ("x" == x ? i : 3 & i | 8).toString(16)
      }.bind(this));
      return chrome.storage.local.set({
        uid: x
      }), x
    }
  }
}