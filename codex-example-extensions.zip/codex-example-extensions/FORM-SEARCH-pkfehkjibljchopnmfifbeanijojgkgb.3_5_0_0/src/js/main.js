var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["January","Feburary","March","April","May","June","July","August","September","October","November","December"];

function pad (str, max=2) {
  str = str.toString();
  return str.length < max ? pad ( "0" + str, max ) : str;
}

const debounce = (callback, wait) => {
  let timeoutId = null;
  return (...args) => {
    window.clearTimeout(timeoutId);
    timeoutId = window.setTimeout(() => {
      callback.apply(null, args);
    }, wait);
  };
}


(function($){
  const saveNotes = debounce(async () => {
    const notes = {}
    $('.sticky-note.editable').each(function() {
      const $note = $(this);
      const id = $note.attr('id');
      const title = $note.find('input').val();
      const content = $note.find('textarea').val();
      notes[id] = {id, title, content};
      console.log(id, title, content)
    })
    console.log('updating notes', notes);

    await window.chrome.storage.sync.set({notes});
  }, 500);

  const fetchNotes = async () => {
    console.log('fetching')
    const {notes = {}} = await window.chrome.storage.sync.get(['notes']);
    console.log('fetching', notes)
    $('.sticky-note.editable').each(function() {
      const $note = $(this);
      const id = $note.attr('id');
      if (!notes[id]) {return;}
      console.log(notes[id]);
      $note.find('input').val(notes[id].title)
      $note.find('textarea').val(notes[id].content)
    })
  };

  const monitorNotes = async () => {
    $('.sticky-note.editable :input').on('input', saveNotes);
  };
  
  function updateTime() {
    const now = new Date()
    $('.rn-time').text(now.toLocaleTimeString())
    $('.rn-date').text(pad(now.getDate()) + '/' +pad(now.getMonth() + 1)+'/'+now.getFullYear());
  }

  function toggleSubmit() {
    $('.search-form input[type=search]').on('input', (e) => $('.search-form button[type=submit]').prop('disabled', !e.target.value))
  }
  setInterval(updateTime, 1000);
  updateTime();
  fetchNotes();
  monitorNotes();
  toggleSubmit();
  
}(jQuery))