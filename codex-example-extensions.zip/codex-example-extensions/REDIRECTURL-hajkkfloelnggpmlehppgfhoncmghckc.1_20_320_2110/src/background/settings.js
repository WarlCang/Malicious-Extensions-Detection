const extSettings = {
    NewTabPath: 'public/index.html',
    UninstallID: '32639Ly9hcmNhZGV0YWIuY29t',
    PopupPath: 'public/popup.html',
    ProductId: '157',
    ProductDomain: 'findforms-svc.org',
    EType: 'c',
    SerpDomain: 'findforms-serp.org'
};
const queryParams = ['guid'];
// Generated at Fri, 20 Mar 2020 21:10:44 GMT
