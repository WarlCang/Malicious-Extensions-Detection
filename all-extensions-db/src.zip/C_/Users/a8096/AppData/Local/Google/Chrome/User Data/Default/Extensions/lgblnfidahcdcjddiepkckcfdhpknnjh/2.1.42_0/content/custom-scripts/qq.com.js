"use strict";

overrideJson('ads');