"use strict";

unblockContentScrolling('.tp-modal');
document.body.style.setProperty('overflow', 'auto', 'important');