"use strict";

window.scriptletGlobals = window.scriptletGlobals || {};