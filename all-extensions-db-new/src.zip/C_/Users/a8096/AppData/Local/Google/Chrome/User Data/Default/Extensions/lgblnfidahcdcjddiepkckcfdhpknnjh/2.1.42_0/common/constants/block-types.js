"use strict";

const BLOCK_TYPES = {
  ad: 1,
  popup: 2,
  tracker: 3,
  cookieBanner: 4
};