"use strict";

unblockContentScrolling('[data-nosnippet="data-nosnippet"]');
unblockContentScrolling('.fc-ab-root');