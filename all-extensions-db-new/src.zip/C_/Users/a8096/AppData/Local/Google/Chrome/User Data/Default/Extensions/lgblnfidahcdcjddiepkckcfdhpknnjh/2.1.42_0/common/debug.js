"use strict";

const debug = {
  log(...args) {},
  error(...args) {}
};