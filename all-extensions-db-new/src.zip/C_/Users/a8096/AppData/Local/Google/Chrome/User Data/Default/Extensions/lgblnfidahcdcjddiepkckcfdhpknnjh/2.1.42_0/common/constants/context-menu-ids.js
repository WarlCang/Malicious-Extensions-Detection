"use strict";

const CONTEXT_MENU_IDS = {
  blockElements: 'block-elements',
  blockElementsPage: 'block-elements-page',
  disable: 'disable',
  disablePage: 'disable-page',
  separatorPage: 'separator-page',
  siteDisable: 'site-disable',
  siteDisablePage: 'site-disable-page',
  standsPage: 'stands-page',
  unblockElements: 'unblock-elements',
  unblockElementsPage: 'unblock-elements-page'
};