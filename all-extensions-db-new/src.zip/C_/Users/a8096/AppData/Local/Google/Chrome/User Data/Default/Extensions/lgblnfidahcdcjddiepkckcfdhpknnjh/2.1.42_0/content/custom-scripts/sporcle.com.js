"use strict";

unblockContentScrolling('[style*="sporcle.com/images"]');