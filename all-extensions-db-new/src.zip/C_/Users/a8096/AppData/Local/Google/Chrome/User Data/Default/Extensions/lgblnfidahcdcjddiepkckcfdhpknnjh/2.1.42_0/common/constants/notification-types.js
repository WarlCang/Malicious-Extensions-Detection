"use strict";

const NOTIFICATION_TYPES = {
  extensionOnOff: 'extension-on-off',
  siteOnOff: 'site-on-off',
  rate: 'rate',
  reactivate: 'reactivate',
  unblock: 'unblock',
  standsBrowserPromo: 'stands-browser-promo'
};