"use strict";

const ICON_BADGE_PERIODS = {
  Page: 'Page',
  Today: 'Today',
  Disabled: 'Disabled'
};