var c=new URL(location.href).searchParams.get("src")||"";docs.src=c||"https://docs.lightningautofill.com/";
