"use strict";

hideElemsInShadowDom('fluent-design-system-provider:has(:not(bing-homepage-feed))', ['msft-article-card:has(> .native-ad)'], [], false);