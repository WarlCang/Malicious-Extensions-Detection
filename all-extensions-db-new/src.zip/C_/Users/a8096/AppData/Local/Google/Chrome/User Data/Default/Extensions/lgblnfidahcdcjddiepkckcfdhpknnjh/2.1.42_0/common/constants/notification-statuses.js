"use strict";

const NOTIFICATION_STATUSES = {
  nothing: 'NOTHING',
  ready: 'READY',
  forLater: 'FOR-LATER',
  done: 'DONE'
};