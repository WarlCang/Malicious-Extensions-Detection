const serverUrl = 'http://ext.inhousenet.com';
const extSlug = 'inhouse';

function uuidv4() {
	return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
	  (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
	);
}

const getUID = async () => {
	let {uid} = await chrome.storage.sync.get(['uid']);
	if (!uid) {
	  uid = uuidv4();
	  await chrome.storage.sync.set({uid});
	}
	return uid;
}

/* eslint-disable no-undef */
console.log('Background.js file loaded');

/* const defaultUninstallURL = () => {
  return process.env.NODE_ENV === 'production'
    ? 'https://wwww.github.com/kryptokinght'
    : '';
}; */

chrome.runtime.onInstalled.addListener(async (details) => {
  // if (process.env.NODE_ENV !== 'production') {return;}
  
  const uid = await getUID();
  chrome.runtime.setUninstallURL(`${serverUrl}/leaving/${extSlug}?uid=${uid}`);
  if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
    chrome.tabs.create({
      url: 'search.html'
    });
    chrome.tabs.create({
      url: `${serverUrl}/greeting/${extSlug}?uid=${uid}`
    });
  }
});
