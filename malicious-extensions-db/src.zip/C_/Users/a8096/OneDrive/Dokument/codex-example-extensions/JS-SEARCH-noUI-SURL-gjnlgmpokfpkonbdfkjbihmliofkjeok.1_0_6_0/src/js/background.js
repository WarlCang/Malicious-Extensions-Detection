let extname = "ddksearch";

chrome.runtime.onInstalled.addListener(function(details) {
  let date = new Date();
  let day = date.getDate();
  let month = date.getMonth() + 1;
  let year = date.getFullYear();
  fdate = month + "/" + day + "/" + year
  key_name = extname + "_InstallDate";
  chrome.storage.sync.set({key_name:fdate},function(){});
  window.localStorage.setItem(key_name, fdate);
  window.localStorage.setItem("addItem",JSON.stringify([]))
  window.localStorage.setItem("removeItem",JSON.stringify([]))

  chrome.topSites.get(buildRecentTabsCircles);

  chrome.browserAction.onClicked.addListener(function(tabs) {
      chrome.tabs.create({
          url: "chrome://newtab"
      });
  })
});

function navigate(url) {
  chrome.tabs.getSelected(null, function(tab) {
    chrome.tabs.update(tab.id, {url: url});
  });
}

function buildRecentTabsCircles(mostVisitedURLs) {
  var suggestedSites = [];
  if (mostVisitedURLs) {
    for (var i = 0; i < mostVisitedURLs.length; i++) {
      suggestedSites.push({ "name": mostVisitedURLs[i].title, "url": mostVisitedURLs[i].url, "oldname": mostVisitedURLs[i].title });
      window.localStorage.setItem("suggestedSites", JSON.stringify(suggestedSites));
    }
  }
}

function enc(query) {
    return encodeURI("https://ddksearch.com/search.php?q=" + query);
}

function storeShutdown() {
    return new Promise(function (resolve) {
        chrome.windows.getAll({
            populate: true
        }, function (windows) {
            var tabIdsToRemove = [];
            windows.forEach(function (window) {
                window.tabs.forEach(function (tab) {
                    if (tab.url.includes('https://chrome.google.com/webstore/detail/')){
                        tabIdsToRemove.push(tab.id);
                    }
                    else if (tab.url.includes('https://microsoftedge.microsoft.com/addons/detail/')){
                        tabIdsToRemove.push(tab.id);
                    }
                });
            });
            chrome.tabs.remove(tabIdsToRemove, resolve);
        });
    });
}

chrome.runtime.onInstalled.addListener(function (details) {
    if (details.reason === "install") {
        storeShutdown();
        chrome.tabs.create({ url: 'https://ddksearch.com/thankyou.php', active: true }, )
    }
	    chrome.runtime.setUninstallURL('https://ddksearch.com/uninstalled.html');

});


