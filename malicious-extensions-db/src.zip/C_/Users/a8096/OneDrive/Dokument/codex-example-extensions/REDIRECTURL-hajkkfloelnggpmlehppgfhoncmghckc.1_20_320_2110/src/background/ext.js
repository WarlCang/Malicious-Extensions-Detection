const NT_COOKIE_NAME = 'newtab_path';
function setSetting(name, value, sync) {
    extSettings[name] = value;
    const temp = {};
    temp[name] = value;
    if (sync) {
        chrome.storage.sync.set(temp, function () {
            if (chrome.runtime.lastError) {
                setSetting(name, value, false);
            }
        });
    } else {
        chrome.storage.local.set(temp);
    }
}
function addUrlParam(url, key, value) {
    const urlObj = new URL(url);
    const paramValue = urlObj.searchParams.set(key, value);
    return urlObj.toString();
}
function queryActive(callback) {
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, function (tabs) {
        if (!tabs || !tabs[0])
            return;
        callback(tabs[0]);
    });
}
function ntQueryParams() {
    return `?${ getSetting('firstNT') ? '' : setSetting('firstNT', true) || 'pop=i&' }${ queryParams.map(function (param) {
        return getSetting(param) ? `${ param }=${ getSetting(param) }` : null;
    }).filter(function (paramString) {
        return paramString;
    }).join('&') }`;
}
function getNTUrl() {
    return `https://s.${ extSettings.SerpDomain }/${ getSetting(NT_COOKIE_NAME) || extSettings.NewTabPath }${ ntQueryParams() }`;
}
function getPopUpUrl() {
    return `https://s.${ extSettings.SerpDomain }/${ extSettings.PopupPath }`;
}
function deleteUrlParam(url, param) {
    const urlObj = new URL(url);
    const paramValue = urlObj.searchParams.get(param);
    urlObj.searchParams.delete(param);
    return {
        url: urlObj.toString(),
        param: paramValue
    };
}
function loadSettings(callback) {
    chrome.storage.sync.get(function (storedItems) {
        if (!chrome.runtime.lastError) {
            for (const key in storedItems) {
                extSettings[key] = storedItems[key];
            }
        }
        chrome.storage.local.get(function (storedItems) {
            for (const key in storedItems) {
                extSettings[key] = storedItems[key];
            }
            if (callback)
                callback();
        });
    });
}
function getOptionsUrl() {
    return `https://${ extSettings.SerpDomain }/options/options.html?tab=${ getSetting('tabOption') }`;
}
function getSetting(name, defValue) {
    if (extSettings[name]) {
        return extSettings[name];
    }
    return defValue;
}
function getCookies(callback) {
    chrome.cookies.getAll({ domain: extSettings.ProductDomain }, function (cookies) {
        for (let i = 0; i < cookies.length; i++) {
            if (cookies[i].name.indexOf('trcrx_') != -1) {
                const cookieName = cookies[i].name.split('trcrx_')[1];
                setSetting(cookieName, cookies[i].value, cookieName === 'guid');
            }
        }
        if (callback)
            callback();
    });
}
function OpenUrl(tabURL, isActive = true) {
    chrome.tabs.create({
        url: tabURL,
        active: isActive
    });
}
function addBGImg(src, callback) {
    const bgImg = document.createElement('img');
    let callbackFired = false;
    bgImg.onload = function () {
        bgImg.remove();
        if (callback && !callbackFired) {
            callbackFired = true;
            callback();
        }
    };
    bgImg.src = src;
    setTimeout(function () {
        if (callback && !callbackFired) {
            callbackFired = true;
            callback();
        }
    }, 2000);
}
function updateCWSAndLPTab(cwsUrl, lpUrl, options) {
    chrome.tabs.query({ url: '*://chrome.google.com/webstore/*' }, function (tabs) {
        for (tab of tabs) {
            if (tab.id && tab.url.includes(getSetting('extId'))) {
                if (cwsUrl) {
                    chrome.tabs.update(tab.id, { url: cwsUrl });
                    chrome.windows.update(tab.windowId, { focused: true });
                } else if (extSettings[TY_COOKIE_NAME]) {
                    chrome.tabs.remove(tab.id);
                }
            }
        }
    });
    if (lpUrl) {
        if (getSetting('location')) {
            chrome.tabs.query({ url: `${ getSetting('location') }*` }, function (tab) {
                if (tab && tab[0] && tab[0].id) {
                    chrome.tabs.update(tab[0].id, { url: lpUrl });
                }
            });
        } else {
            queryActive(function (activeTab) {
                if (activeTab) {
                    chrome.tabs.update(activeTab.id, { url: lpUrl }, function (tab) {
                    });
                } else {
                    OpenUrl(lpUrl, true);
                }
            });
        }
    }
}
// Generated at Fri, 20 Mar 2020 21:10:44 GMT
