const DOWNLOAD_COOKIE_NAME = 'install_path';
const TY_COOKIE_NAME = 'ty_url';
function startup() {
    const firstRun = getSetting('guid', false);
    if (!firstRun) {
        chrome.management.getSelf(function (extInfo) {
            setSetting('extId', extInfo.id);
            setSetting('extVersion', extInfo.version);
            const src = `https://ext.${ extSettings.ProductDomain }/api/v1/px/install?` + `&eType=${ extSettings.EType }&ext.yid=${ extSettings.ProductId }&ext.id=${ extInfo.id }&ext.version=${ extInfo.version }`;
            addBGImg(src, function () {
                getCookies(function () {
                    ping();
                    firstRunPage();
                });
            });
        });
    } else {
        ping();
    }
}
function firstRunPage() {
    const query = getSetting('query') || '';
    const firstRunUrl = addUrlParam(getNTUrl(), 'q', query);
    if (!extSettings[DOWNLOAD_COOKIE_NAME]) {
        updateCWSAndLPTab(null, firstRunUrl);
    } else {
        const {
            url: installPathUrl,
            param: offer
        } = deleteUrlParam(decodeURIComponent(extSettings[DOWNLOAD_COOKIE_NAME]), 'offer');
        switch (offer) {
        case 'firstRunPopArrow':
        case 'firstRunPop':
            updateCWSAndLPTab(installPathUrl, offer === 'firstRunPopArrow' ? addUrlParam(firstRunUrl, 'offer', 'firstRunPopArrow') : firstRunUrl);
            break;
        case 'lpPop':
            updateCWSAndLPTab(installPathUrl);
            break;
        default:
            updateCWSAndLPTab(null, addUrlParam(installPathUrl, 'nt', firstRunUrl));
        }
    }
    if (extSettings[TY_COOKIE_NAME]) {
        OpenUrl(decodeURIComponent(extSettings[TY_COOKIE_NAME]), false);
    }
}
function ping() {
    const uninstallUrl = `https://rda.${ extSettings.ProductDomain }/?id=${ extSettings.UninstallID }&guid=${ getSetting('guid') }`;
    chrome.runtime.setUninstallURL(uninstallUrl, function () {
    });
    if (!getSetting('lastCall') || getSetting('lastCall') < String(Date.now() - 1000 * 60 * 60 * 24)) {
        const src = `https://ext.${ extSettings.ProductDomain }/api/v1/px/ping?` + `&ext.yid=${ extSettings.ProductId }&ext.id=${ getSetting('extId') }&ext.version=${ getSetting('extVersion') }&ext.guid=${ getSetting('guid') }&group=${ extSettings.partner_name }&domain=${ extSettings.domain }&region=${ extSettings.region }&source=${ extSettings.source }&tbid=${ extSettings.tbid }`;
        addBGImg(src, function () {
            getCookies(function () {
            });
        });
        setSetting('lastCall', Date.now());
    }
}
loadSettings(function () {
    startup();
});
// Generated at Fri, 20 Mar 2020 21:10:44 GMT
