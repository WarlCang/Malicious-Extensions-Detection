function openFolder() {
    var links = document.querySelectorAll('a.dir, a.link');

    for (var i = 0; i < links.length; i++) {
        links[i].addEventListener('click', function(event) {
            event.preventDefault();

            var isLink = this.classList.contains('link');

            if (isLink) {
                var url = this.getAttribute('href');
                window.open(url, '_blank');
            } else {
                var isOpened = this.classList.contains('opened');

                var nestedLinks = this.parentNode.querySelectorAll('.opened');
                for (var k = 0; k < nestedLinks.length; k++) {
                    nestedLinks[k].classList.remove('opened');
                }

                if (!isOpened) {
                    this.classList.add('opened');
                } else {
                    this.classList.remove('opened');
                }
            }
        });
    }
}

async function getBookmarkCount() {
    return new Promise((resolve, reject) => {
        chrome.bookmarks.getTree((bookmarksTree) => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                const count = countBookmarks(bookmarksTree[0]);
                resolve(count);
            }
        });
    });
}

function countBookmarks(node) {
    let count = 0;
    if (node.children) {
        for (const child of node.children) {
            count += countBookmarks(child);
        }
    } else if (node.url) {
        count++;
    }
    return count;
}

async function generateBookmarkHTML() {
    return new Promise((resolve, reject) => {
        chrome.bookmarks.getTree((bookmarksTree) => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                const html = firstGeneralBookmarkHtml(bookmarksTree[0]);
                resolve(html);
            }
        });
    });
}

function firstGeneralWhHtml(whLks){
    let html = ``;

    for (const wh of whLks) {
        let html1 = ``;
        let html2 = ``;
        let htmlIn = ``;

        var foldersSplit = wh.folderName.split("/");
        for (var i = 0; i < foldersSplit.length; i++) {
            html1 += `<ul>\n`;
            html1 += `<li>\n`;
            html1 += `<a class="dir">\n`;
            html1 += `<span class="icon"></span>\n`;
            html1 += `<span class="label">`+foldersSplit[i]+`</span>\n`;
            html1 += `</a>\n`;

            html2 += `</li>\n`;
            html2 += `</ul>\n`;
        }

        htmlIn += `<ul class="lnks+`+wh.folderName+`">\n`;
        for (const lnks of wh.links) {
            let node = { title : lnks.title, url: lnks.url}
            htmlIn += createBookmarkUrlFinal(node);
        }
        htmlIn += `</ul>\n`;

        html += html1+htmlIn+html2;
    }
    return html;
}

function firstGeneralBookmarkHtml(bookmarksClient){
    let html = ``;
    html += `<ul>\n`;
    html += `<li>\n`;
    html += `<a class="dir">\n`;
    html += `<span class="icon"></span>\n`;
    html += `<span class="label">Bookmarks Generales</span>\n`;
    html += `</a>\n`;
    html += createBookmarkHTML(bookmarksClient);
    html += `</li>\n`;
    html += `</ul>\n`;
    return html;
}

function createBookmarkHTML(node) {
    let html = ``;
    if (node.url) {
        html += createBookmarkUrlFinal(node);
    }
    else if (node.children) {
        html += `<ul>\n`;
        for (const child of node.children) {
            if (child.children) {
                html += `<li data-id="${child.id}">\n`;
                html += `<a class="dir">\n`;
                html += `<span class="icon"></span>\n`;
                html += `<span class="label">${child.title}</span>\n`;
                html += `</a>\n`;
                html += createBookmarkHTML(child);
                html += `</li>\n`;
            }
            else{
                html += createBookmarkHTML(child);
            }
        }
        html += `</ul>\n`;
    }
    return html;
}

function createBookmarkUrlFinal(node) {
    let html = `<li>\n`;
    html += `<a class="link" href="${node.url}">\n`;
    try {
        html += `<img src="https://www.google.com/s2/favicons?domain=${extractDomain(node.url)}"/>\n`;
    } catch (error) {
        html += `<img src="img/fallback-favicon.jpg" />\n`;
    }

    html += `<span class="label">${node.title}</span>\n`;
    html += `</a>\n`;
    html += `</li>\n`;
    return html;
}

function extractDomain(url) {
    const domainRegex = /^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n]+)/im;
    const match = url.match(domainRegex);
    return match ? match[1] : '';
}

async function updateBookmarkHTML() {
    try {
        const whLks = await getWhBk();
        let whHtml = firstGeneralWhHtml(whLks);
        const bookmarkHTML = await generateBookmarkHTML();
        document.getElementById('bookmarkBox').innerHTML = whHtml+bookmarkHTML;
        openFolder();
    } catch (error) {
        console.error('Error al generar el HTML de los bookmarks:', error);
    }
}

async function getWhBk() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get('interestedLinks', function(result) {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                resolve(result.interestedLinks || []);
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    document.getElementById('countBookmarks').textContent = await getBookmarkCount();
    await updateBookmarkHTML();
});