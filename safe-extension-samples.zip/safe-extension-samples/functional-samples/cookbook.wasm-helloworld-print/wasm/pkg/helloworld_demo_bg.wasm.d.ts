/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function main(): void;
export function print(): void;
export function print_with_value(a: number, b: number): void;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export function __wbindgen_start(): void;
