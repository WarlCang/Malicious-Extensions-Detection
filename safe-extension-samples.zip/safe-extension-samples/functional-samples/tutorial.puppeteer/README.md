# Tutorial: Testing Chrome Extensions with Puppeteer

## Overview

This is the sample code for the [Testing Chrome Extensions with Puppeteer](https://developer.chrome.com/docs/extensions/mv3/tut_puppeteer-testing/) tutorial.

## Running the tests

1. Install [Node.JS](https://nodejs.org/).
2. Run `npm install`.
3. Run `npm start`.
