# Custom Cursor extension

Adds a custom cursor to pages on https://developer.chrome.com. This sample is part of a [tutorial on YouTube](https://www.youtube.com/watch?v=QYgKhYbJFUU).

## Running this extension

1. Clone this repository.
2. Load this directory in Chrome as an [unpacked extension](https://developer.chrome.com/docs/extensions/mv3/getstarted/development-basics/#load-unpacked).
3. Open https://developer.chrome.com.
